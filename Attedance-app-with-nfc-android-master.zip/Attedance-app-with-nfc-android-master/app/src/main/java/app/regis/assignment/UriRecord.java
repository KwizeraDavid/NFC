package app.regis.assignment;

public class UriRecord {
}
