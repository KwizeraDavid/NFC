package app.regis.assignment;

public class ParsedNdefRecord {
}
