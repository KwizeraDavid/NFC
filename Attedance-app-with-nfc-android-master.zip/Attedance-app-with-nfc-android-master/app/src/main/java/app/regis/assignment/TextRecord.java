package app.regis.assignment;

class TextRecord {
}
